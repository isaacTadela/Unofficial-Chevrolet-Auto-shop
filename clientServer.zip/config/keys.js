dbPassword = 'mongodb+srv://isaacT:'+ 
encodeURIComponent('1Q2W3E4R5T6Y') + '@cluster1-oonad.mongodb.net/clientServer?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
